/**
 * All rights reserved. Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.jivesoftware.smackx;


/**
 * Since dalvik on Android does not allow the loading of META-INF files from the
 * filesystem, the static blocks of some classes have to be inited manually.
 *
 * The full list can be found here:
 * http://fisheye.igniterealtime.org/browse/smack/trunk/build/resources/META-INF/smack-config.xml?hb=true
 *
 * @author Florian Schmaus fschmaus@gmail.com
 *
 */
public class InitAsmack {
    
    /**
     * Call this method prior the creation of any (XMPP)Connection Object.
     * It's a good idea to place the call early in the programs life cycle!
     */
    public static void init() {
        initStatic();
        ConfigureProviderManager.configureProviderManager();
    }
    
    public static void initStatic() {
        try {
            Class.forName("org.jivesoftware.smackx.ServiceDiscoveryManager", true, ClassLoader.getSystemClassLoader());
            Class.forName("org.jivesoftware.smack.PrivacyListManager", true, ClassLoader.getSystemClassLoader());
            Class.forName("org.jivesoftware.smackx.XHTMLManager", true, ClassLoader.getSystemClassLoader());
            Class.forName("org.jivesoftware.smackx.muc.MultiUserChat", true, ClassLoader.getSystemClassLoader());
            Class.forName("org.jivesoftware.smackx.bytestreams.ibb.InBandBytestreamManager", true, ClassLoader.getSystemClassLoader());
            Class.forName("org.jivesoftware.smackx.bytestreams.socks5.Socks5BytestreamManager", true, ClassLoader.getSystemClassLoader());
            Class.forName("org.jivesoftware.smackx.filetransfer.FileTransferManager", true, ClassLoader.getSystemClassLoader());
            Class.forName("org.jivesoftware.smackx.LastActivityManager", true, ClassLoader.getSystemClassLoader());
            Class.forName("org.jivesoftware.smack.ReconnectionManager", true, ClassLoader.getSystemClassLoader());
            Class.forName("org.jivesoftware.smackx.commands.AdHocCommandManager", true, ClassLoader.getSystemClassLoader());
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("Could not init static class blocks", e);
        }
    }
}


